class Base {
    private String secret = "Private Data";
    protected String info = "Protected Info";

    public void printInfo() {
        System.out.println("Base: " + secret + " | " + info);
    }
}

public class AccessControlDemo extends Base {
    public static void main(String[] args) {
        AccessControlDemo demo = new AccessControlDemo();
        demo.printInfo();
        System.out.println("Accessing protected info: " + demo.info);
    }
}