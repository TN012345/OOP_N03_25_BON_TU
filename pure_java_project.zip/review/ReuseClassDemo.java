class Animal {
    public void speak() {
        System.out.println("Animal sound...");
    }
}

class Dog extends Animal {
    @Override
    public void speak() {
        System.out.println("Woof! Woof!");
    }
}

public class ReuseClassDemo {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.speak();
    }
}