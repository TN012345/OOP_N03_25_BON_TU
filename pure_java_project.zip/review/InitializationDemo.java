public class InitializationDemo {
    private String message;

    {
        message = "Initialized in block";
    }

    public InitializationDemo() {
        System.out.println("Constructor called");
    }

    public void showMessage() {
        System.out.println(message);
    }

    public static void main(String[] args) {
        InitializationDemo obj = new InitializationDemo();
        obj.showMessage();
    }
}