public class TestRecursion {
    public static void main(String[] args) {
        System.out.println("Factorial 5 = " + Recursion.factorial(5));
        System.out.println("Fibonacci(7) = " + Recursion.fibonacci(7));
    }
}