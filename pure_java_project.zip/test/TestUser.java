public class TestUser {
    public static void main(String[] args) {
        User u = new User(1, "Alice", "alice@example.com");
        System.out.println(u);
    }
}